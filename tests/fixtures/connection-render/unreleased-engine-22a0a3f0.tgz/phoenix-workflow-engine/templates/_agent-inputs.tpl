{{- define "phoenix-workflow-engine.agentInputsName" -}}
{{- printf "%s-agent-inputs" (include "phoenix-workflow-engine.fullname" . | trunc 50 | trimSuffix "-") -}}
{{- end -}}

{{- define "phoenix-workflow-engine.agentInputDestination" -}}
{{- if or (not (regexMatch .policy.grammar .name)) (has .name .policy.reservedExact) (hasPrefix "PHOENIX_LLM_" .name) -}}
  {{- fail "agent inputs invalid_destination" -}}
{{- end -}}
{{- $prefixes := .policy.reservedPrefixes -}}
{{- if .secret -}}{{- $prefixes = concat $prefixes .policy.secretOnlyReservedPrefixes -}}{{- end -}}
{{- range $prefixes -}}
  {{- if hasPrefix . $.name -}}{{- fail "agent inputs reserved_destination" -}}{{- end -}}
{{- end -}}
{{- end -}}

{{- /* Return validated complete maps; reject overlaps before combining sources. */ -}}
{{- define "phoenix-workflow-engine.agentInputs" -}}
{{- $generic := .Values.agentInputDelivery -}}
{{- $contract := .Files.Get "contracts/agent-input-delivery/v1/contract.json" | fromJson -}}
{{- if not (kindIs "slice" $generic.allowedEnterpriseIds) -}}{{- fail "agent inputs enterprise_policy_required" -}}{{- end -}}
{{- if or (eq (len $generic.allowedEnterpriseIds) 0) (gt (len $generic.allowedEnterpriseIds) (int $contract.policy.uniqueNonemptyCanonicalEnterpriseIdsMax)) -}}{{- fail "agent inputs invalid_enterprise_policy" -}}{{- end -}}
{{- $enterprises := dict -}}
{{- range $generic.allowedEnterpriseIds -}}
  {{- if not (kindIs "string" .) -}}{{- fail "agent inputs invalid_enterprise_policy" -}}{{- end -}}
  {{- if or (not (regexMatch $contract.policy.enterprisePattern .)) (hasKey $enterprises .) -}}{{- fail "agent inputs invalid_enterprise_policy" -}}{{- end -}}
  {{- $_ := set $enterprises . true -}}
{{- end -}}
{{- $plain := dict -}}
{{- $secrets := dict -}}
{{- $owners := dict -}}
{{- if .Values.llm -}}
  {{- $named := include "phoenix-workflow-engine.llmInputs" . | fromJson -}}
  {{- range $name, $value := $named.env -}}
    {{- $_ := set $owners $name "llm.connections" -}}
    {{- $_ := set $plain $name $value -}}
  {{- end -}}
{{- end -}}
{{- range $source, $input := dict "agentInputDelivery" $generic "llm" (.Values.llm | default dict) -}}
  {{- range $name, $value := ($input.env | default dict) -}}
    {{- include "phoenix-workflow-engine.agentInputDestination" (dict "name" $name "secret" false "policy" $contract.names) -}}
    {{- if not (kindIs "string" $value) -}}{{- fail "agent inputs invalid_plain_value" -}}{{- end -}}
    {{- if regexMatch `\x00` $value -}}{{- fail (printf "%s.env source_required" $source) -}}{{- end -}}
    {{- if hasKey $owners $name -}}
      {{- fail (printf "%s.env destination_collision overlaps %s" $source (index $owners $name)) -}}
    {{- end -}}
    {{- $_ := set $owners $name (printf "%s.env" $source) -}}
    {{- $_ := set $plain $name $value -}}
  {{- end -}}
  {{- range $name, $reference := ($input.secretEnv | default dict) -}}
    {{- include "phoenix-workflow-engine.agentInputDestination" (dict "name" $name "secret" true "policy" $contract.names) -}}
    {{- if hasKey $owners $name -}}
      {{- fail (printf "%s.secretEnv destination_collision overlaps %s" $source (index $owners $name)) -}}
    {{- end -}}
    {{- $_ := set $owners $name (printf "%s.secretEnv" $source) -}}
    {{- $_ := set $secrets $name $reference -}}
  {{- end -}}
{{- end -}}
{{- if gt (len $plain) 256 -}}{{- fail "agent inputs exceed 256 plain destinations" -}}{{- end -}}
{{- if gt (len $secrets) 128 -}}{{- fail "agent inputs exceed 128 secret destinations" -}}{{- end -}}
{{- $envJSON := toJson $plain -}}
{{- $policyJSON := toJson (dict "version" 1 "allowedEnterpriseIds" $generic.allowedEnterpriseIds) -}}
{{- if gt (len $envJSON) 65536 -}}{{- fail "agent inputs env.json exceeds 65536 bytes" -}}{{- end -}}
{{- if gt (len $policyJSON) 65536 -}}{{- fail "agent inputs delivery-policy.json exceeds 65536 bytes" -}}{{- end -}}
{{- $directory := "/var/run/phoenix/agent-inputs" -}}
{{- range .Values.operator.extraVolumes -}}
  {{- if eq .name "agent-inputs" -}}{{- fail "operator.extraVolumes reserves agent-inputs" -}}{{- end -}}
{{- end -}}
{{- range .Values.operator.extraVolumeMounts -}}
  {{- if eq .name "agent-inputs" -}}{{- fail "operator.extraVolumeMounts reserves agent-inputs" -}}{{- end -}}
  {{- $path := clean .mountPath -}}
  {{- if or (eq $path "/") (eq $path $directory) (hasPrefix (printf "%s/" $path) $directory) (hasPrefix (printf "%s/" $directory) $path) -}}
    {{- fail "operator.extraVolumeMounts overlaps agent inputs directory" -}}
  {{- end -}}
{{- end -}}
{{- dict "env" $envJSON "policy" $policyJSON "secrets" $secrets | toJson -}}
{{- end -}}
