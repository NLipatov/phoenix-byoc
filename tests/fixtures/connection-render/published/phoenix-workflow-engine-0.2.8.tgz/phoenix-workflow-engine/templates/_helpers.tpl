{{/*
Chart name, truncated to 63 chars.
*/}}
{{- define "phoenix-workflow-engine.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Fully qualified app name.
*/}}
{{- define "phoenix-workflow-engine.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart label value.
*/}}
{{- define "phoenix-workflow-engine.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels.
*/}}
{{- define "phoenix-workflow-engine.labels" -}}
helm.sh/chart: {{ include "phoenix-workflow-engine.chart" . }}
app.kubernetes.io/name: {{ include "phoenix-workflow-engine.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels.
*/}}
{{- define "phoenix-workflow-engine.selectorLabels" -}}
app.kubernetes.io/name: {{ include "phoenix-workflow-engine.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Container image reference.
*/}}
{{- define "phoenix-workflow-engine.image" -}}
{{- printf "%s:%s" .Values.image.repository (default .Chart.AppVersion .Values.image.tag) }}
{{- end }}

{{- define "phoenix-workflow-engine.databaseHost" -}}
{{- required "database.host is required" .Values.database.host }}
{{- end }}

{{- define "phoenix-workflow-engine.databasePort" -}}
{{- .Values.database.port | default 5432 }}
{{- end }}

{{- define "phoenix-workflow-engine.databaseName" -}}
{{- required "database.name is required" .Values.database.name }}
{{- end }}

{{- define "phoenix-workflow-engine.databaseUser" -}}
{{- required "database.user is required" .Values.database.user }}
{{- end }}

{{- define "phoenix-workflow-engine.databasePassword" -}}
{{- required "database.password is required" .Values.database.password }}
{{- end }}

{{- define "phoenix-workflow-engine.databaseUrl" -}}
{{- printf "postgres://%s:%s@%s:%v/%s?sslmode=%s&connect_timeout=10" (include "phoenix-workflow-engine.databaseUser" .) (include "phoenix-workflow-engine.databasePassword" .) (include "phoenix-workflow-engine.databaseHost" .) (include "phoenix-workflow-engine.databasePort" .) (include "phoenix-workflow-engine.databaseName" .) (.Values.database.sslmode | default "disable") }}
{{- end }}

{{- define "phoenix-workflow-engine.internalDatabaseHost" -}}
{{- required "internalDatabase.host is required" .Values.internalDatabase.host }}
{{- end }}

{{- define "phoenix-workflow-engine.internalDatabasePort" -}}
{{- .Values.internalDatabase.port | default 5432 }}
{{- end }}

{{- define "phoenix-workflow-engine.internalDatabaseName" -}}
{{- required "internalDatabase.name is required" .Values.internalDatabase.name }}
{{- end }}

{{- define "phoenix-workflow-engine.internalDatabaseUser" -}}
{{- required "internalDatabase.user is required" .Values.internalDatabase.user }}
{{- end }}

{{- define "phoenix-workflow-engine.internalDatabasePassword" -}}
{{- required "internalDatabase.password is required" .Values.internalDatabase.password }}
{{- end }}

{{- define "phoenix-workflow-engine.internalDatabaseUrl" -}}
{{- printf "postgres://%s:%s@%s:%v/%s?sslmode=%s&connect_timeout=10" (include "phoenix-workflow-engine.internalDatabaseUser" .) (include "phoenix-workflow-engine.internalDatabasePassword" .) (include "phoenix-workflow-engine.internalDatabaseHost" .) (include "phoenix-workflow-engine.internalDatabasePort" .) (include "phoenix-workflow-engine.internalDatabaseName" .) (.Values.internalDatabase.sslmode | default "disable") }}
{{- end }}

{{- define "phoenix-workflow-engine.internalAdminDbUrl" -}}
{{- required "internalDatabase.init.adminUrl is required when internalDatabase.init.enabled" .Values.internalDatabase.init.adminUrl }}
{{- end }}

{{- define "phoenix-workflow-engine.conversationStreamRedisUrl" -}}
{{- required "supervisorChat.streamHandoff.redisUrl is required when phoenixWeb.url is set" .Values.supervisorChat.streamHandoff.redisUrl }}
{{- end }}

{{- define "phoenix-workflow-engine.apiServiceName" -}}
{{- printf "%s-api" (include "phoenix-workflow-engine.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "phoenix-workflow-engine.artifactApiServiceName" -}}
{{- printf "%s-artifact-api" (include "phoenix-workflow-engine.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "phoenix-workflow-engine.artifactApiInternalUrl" -}}
{{- printf "http://%s:%v" (include "phoenix-workflow-engine.artifactApiServiceName" .) .Values.artifactApi.port }}
{{- end }}

{{- define "phoenix-workflow-engine.artifactApiSandboxUrl" -}}
{{- if .Values.artifactApi.sandboxBaseUrl }}
{{- .Values.artifactApi.sandboxBaseUrl }}
{{- else }}
{{- include "phoenix-workflow-engine.artifactApiInternalUrl" . }}
{{- end }}
{{- end }}

{{- define "phoenix-workflow-engine.opensandboxServiceName" -}}
{{- printf "%s-opensandbox" (include "phoenix-workflow-engine.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "phoenix-workflow-engine.operatorServiceAccountName" -}}
{{- printf "%s-operator" (include "phoenix-workflow-engine.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "phoenix-workflow-engine.opensandboxClusterRoleName" -}}
{{- default (include "phoenix-workflow-engine.opensandboxServiceName" .) .Values.opensandbox.clusterRoleName }}
{{- end }}

{{- define "phoenix-workflow-engine.opensandboxEndpoint" -}}
{{- if .Values.opensandbox.endpoint }}
{{- .Values.opensandbox.endpoint }}
{{- else if .Values.opensandbox.enabled }}
{{- printf "http://%s:8080" (include "phoenix-workflow-engine.opensandboxServiceName" .) }}
{{- else }}
{{- "" }}
{{- end }}
{{- end }}

{{- define "phoenix-workflow-engine.opensandboxImage" -}}
{{- printf "%s:%s" .Values.opensandbox.image.repository (.Values.opensandbox.image.tag | default "dev") }}
{{- end }}

{{/*
experimentDefs ConfigMap-as-files bodies, shared by the three def-loading
deployments (api, orchestrator, operator) so the mount target / pod-annotation
only need editing in one place. Flat ConfigMap keys are mounted under v1 to
preserve the legacy harness shape while still exposing a versioned catalog root
when workflow.definitionCatalogRoot is set to /etc/workflow-defs. Each emits
just the body — callers keep the `{{- if .Values.workflow.experimentDefs.enabled
}}` gate, because the surrounding key (`volumeMounts:` / `volumes:`) differs per
deployment: api/orchestrator add it fresh (omit the key entirely when disabled)
while operator appends the item under its pre-existing artifacts keys.
*/}}
{{- define "phoenix-workflow-engine.experimentDefsChecksum" -}}
checksum/workflow-defs: {{ include (print $.Template.BasePath "/configmap-workflow-defs.yaml") . | sha256sum }}
{{- end }}

{{- define "phoenix-workflow-engine.experimentDefsVolumeMount" -}}
- name: workflow-defs
  mountPath: /etc/workflow-defs/v1
  readOnly: true
{{- end }}

{{- define "phoenix-workflow-engine.experimentDefsVolume" -}}
- name: workflow-defs
  configMap:
    name: {{ include "phoenix-workflow-engine.fullname" . }}-workflow-defs
{{- end }}
