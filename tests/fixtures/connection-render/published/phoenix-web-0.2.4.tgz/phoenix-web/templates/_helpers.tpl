{{/*
Chart name, truncated to 63 chars.
*/}}
{{- define "phoenix-web.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Fully qualified app name.
*/}}
{{- define "phoenix-web.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart label value.
*/}}
{{- define "phoenix-web.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels.
*/}}
{{- define "phoenix-web.labels" -}}
helm.sh/chart: {{ include "phoenix-web.chart" . }}
app.kubernetes.io/name: {{ include "phoenix-web.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels.
*/}}
{{- define "phoenix-web.selectorLabels" -}}
app.kubernetes.io/name: {{ include "phoenix-web.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Container image reference.
*/}}
{{- define "phoenix-web.image" -}}
{{- printf "%s:%s" .Values.image.repository (default .Chart.AppVersion .Values.image.tag) }}
{{- end }}

{{/*
Database host (Postgres host for Rails primary/cache/queue/cable connections).
*/}}
{{- define "phoenix-web.databaseHost" -}}
{{- required "externalDatabase.host is required" .Values.externalDatabase.host }}
{{- end }}

{{/*
Database port.
*/}}
{{- define "phoenix-web.databasePort" -}}
{{- .Values.externalDatabase.port | default 5432 }}
{{- end }}

{{/*
Database password for the phoenix_web role (PHOENIX_WEB_DATABASE_PASSWORD).
*/}}
{{- define "phoenix-web.databasePassword" -}}
{{- required "externalDatabase.password is required" .Values.externalDatabase.password }}
{{- end }}

{{/*
Admin (superuser) Postgres URL — used by db-init to create the phoenix_web role.
*/}}
{{- define "phoenix-web.adminDbUrl" -}}
{{- required "externalDatabase.init.adminUrl is required when init.enabled" .Values.externalDatabase.init.adminUrl }}
{{- end }}

{{/*
SECRET_KEY_BASE — required for Rails in production.
*/}}
{{- define "phoenix-web.secretKeyBase" -}}
{{- required "secret.secretKeyBase is required (set via SECRET_KEY_BASE in .env)" .Values.secret.secretKeyBase }}
{{- end }}
