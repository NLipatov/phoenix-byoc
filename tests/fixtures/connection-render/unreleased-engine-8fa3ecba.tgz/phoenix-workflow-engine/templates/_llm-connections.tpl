{{- /* Canonical schema owns route fields and API cardinality; capabilities independently own native admission. */ -}}
{{- define "phoenix-workflow-engine.llmInputs" -}}
{{- $llm := .Values.llm -}}
{{- if or (not (kindIs "string" $llm.CONFIG_VERSION)) (ne (toString $llm.CONFIG_VERSION) "1") -}}{{- fail "llm.CONFIG_VERSION invalid_authoring" -}}{{- end -}}
{{- $schema := .Files.Get "contracts/llm-connections/v1/values.schema.json" | fromJson -}}
{{- $rules := .Files.Get "contracts/llm-connections/v1/semantic-rules.json" | fromJson -}}
{{- $capabilities := .Files.Get "contracts/llm-connections/v1/capabilities.json" | fromJson -}}
{{- $controlPattern := "[" -}}
{{- range $range := $rules.controls.disallowedCodePointRanges -}}
  {{- $controlPattern = printf "%s\\x{%x}-\\x{%x}" $controlPattern (int (index $range 0)) (int (index $range 1)) -}}
{{- end -}}
{{- $controlPattern = printf "%s]" $controlPattern -}}
{{- $definitions := $schema.definitions -}}
{{- $plain := dict "PHOENIX_LLM_CONFIG_VERSION" "1" -}}
{{- $names := keys $llm.connections | sortAlpha -}}
{{- $_ := set $plain "PHOENIX_LLM_CONNECTIONS" (join "," $names) -}}
{{- $llmPlain := $llm.env | default dict -}}
{{- $llmSecrets := $llm.secretEnv | default dict -}}
{{- $genericPlain := .Values.agentInputDelivery.env | default dict -}}
{{- $genericSecrets := .Values.agentInputDelivery.secretEnv | default dict -}}
{{- $platform := dict -}}
{{- range $llm.platformEnv | default list -}}
  {{- if or (hasKey $llmPlain .) (hasKey $llmSecrets .) (hasKey $genericPlain .) (hasKey $genericSecrets .) -}}
    {{- fail "llm.platformEnv destination_collision" -}}
  {{- end -}}
  {{- $_ := set $platform . true -}}
{{- end -}}
{{- range $name := $names -}}
  {{- if has $name $rules.forbidden.connectionNames -}}{{- fail "llm.connections invalid_authoring" -}}{{- end -}}
  {{- $connection := index $llm.connections $name -}}
  {{- $route := dict -}}
  {{- range $definitionName, $definition := $definitions -}}
    {{- if and (hasPrefix "llmConnectionsV1_" $definitionName) (hasKey $definition "allOf") -}}
      {{- $properties := (index $definition.allOf 1).properties | default dict -}}
      {{- if and (hasKey $properties "PLATFORM") (eq $connection.PLATFORM (get (get $properties "PLATFORM") "const")) (eq $connection.PUBLISHER (get (get $properties "PUBLISHER") "const")) -}}
        {{- $route = $definition -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
  {{- if not $route -}}{{- fail "llm.connections invalid_route" -}}{{- end -}}
  {{- $routeProperties := (index $route.allOf 1).properties -}}
  {{- $apis := (get $routeProperties "API").enum -}}
  {{- $apiSupplied := hasKey $connection "API" -}}
  {{- $api := $connection.API -}}
  {{- if not $api -}}
    {{- if ne (len $apis) 1 -}}{{- fail "llm.connections.API api_required" -}}{{- end -}}
    {{- $api = index $apis 0 -}}
  {{- end -}}
  {{- if not (has $api $apis) -}}{{- fail "llm.connections.API invalid_api" -}}{{- end -}}
  {{- $headerNames := dict -}}
  {{- range $headerName, $_ := $connection.HEADERS_JSON | default dict -}}
    {{- if has $headerName $rules.forbidden.jsonMemberNames -}}{{- fail "llm.connections.HEADERS_JSON invalid_header" -}}{{- end -}}
    {{- $lower := lower $headerName -}}
    {{- if has $lower $rules.headers.protectedNamesCaseInsensitive -}}{{- fail "llm.connections.HEADERS_JSON invalid_header" -}}{{- end -}}
    {{- if hasKey $headerNames $lower -}}{{- fail "llm.connections.HEADERS_JSON header_case_duplicate" -}}{{- end -}}
    {{- $_ := set $headerNames $lower true -}}
  {{- end -}}
  {{- if hasKey $connection "API_KEY_ENV" -}}
    {{- if not (hasKey $llmSecrets $connection.API_KEY_ENV) -}}
      {{- if or (hasKey $genericSecrets $connection.API_KEY_ENV) (hasKey $llmPlain $connection.API_KEY_ENV) (hasKey $genericPlain $connection.API_KEY_ENV) -}}{{- fail "llm.connections.API_KEY_ENV secret_reference_required" -}}{{- end -}}
      {{- fail "llm.secretEnv source_required" -}}
    {{- end -}}
  {{- end -}}
  {{- if hasKey $connection "BASE_URL" -}}
    {{- $url := $connection.BASE_URL -}}
    {{- if regexMatch $controlPattern $url -}}{{- fail "llm.connections.BASE_URL invalid_url" -}}{{- end -}}
    {{- $host := regexFind `^https://[^/:?#]+` $url | trimPrefix "https://" -}}
    {{- $label := `[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?` -}}
    {{- if or (not (regexMatch (printf `^https://%s(?:\.%s)*(?::[0-9]{1,5})?(?:/[^[:space:]?#]*)?$` $label $label) $url)) (gt (len $host) 253) -}}
      {{- fail "llm.connections.BASE_URL invalid_url" -}}
    {{- end -}}
    {{- $authority := regexFind `^https://[^/]+` $url -}}
    {{- $port := regexFind `:[0-9]+$` $authority | trimPrefix ":" -}}
    {{- if and $port (or (lt (atoi $port) 1) (gt (atoi $port) 65535)) -}}{{- fail "llm.connections.BASE_URL invalid_url" -}}{{- end -}}
  {{- end -}}
  {{- $refs := $connection.NATIVE_ENV_REFS_JSON | default dict -}}
  {{- range $nativeName, $destination := $refs -}}
    {{- if has $nativeName $rules.references.nativePlatformKeys -}}
      {{- if not (hasKey $platform $destination) -}}{{- fail "llm.platformEnv source_required" -}}{{- end -}}
    {{- else -}}
      {{- if not (hasKey $llmPlain $destination) -}}{{- fail "llm.env source_required" -}}{{- end -}}
      {{- if or (eq (index $llmPlain $destination) "") (regexMatch $controlPattern (index $llmPlain $destination)) -}}{{- fail "llm.env source_required" -}}{{- end -}}
    {{- end -}}
  {{- end -}}
  {{- range $headerName, $value := $connection.HEADERS_JSON | default dict -}}
    {{- if regexMatch $controlPattern $value -}}{{- fail "llm.connections.HEADERS_JSON invalid_header" -}}{{- end -}}
    {{- if hasPrefix "$" $value -}}
      {{- $ref := trimPrefix "$" $value -}}
      {{- if not (or (and (has "plain" $rules.references.headerSources) (hasKey $llmPlain $ref)) (and (has "secrets" $rules.references.headerSources) (hasKey $llmSecrets $ref)) (and (has "platform" $rules.references.headerSources) (hasKey $platform $ref))) -}}{{- fail "llm.connections.HEADERS_JSON source_required" -}}{{- end -}}
      {{- if and (hasKey $llmPlain $ref) (or (eq (index $llmPlain $ref) "") (regexMatch $controlPattern (index $llmPlain $ref))) -}}{{- fail "llm.connections.HEADERS_JSON invalid_header" -}}{{- end -}}
    {{- end -}}
  {{- end -}}
  {{- $matches := list -}}
  {{- range $capabilities.entries -}}
    {{- if and (eq .route (get $route "title")) (or (not $apiSupplied) (eq .api $api)) (eq .authMode $connection.AUTH_MODE) -}}
      {{- $matches = append $matches . -}}
    {{- end -}}
  {{- end -}}
  {{- if ne (len $matches) (int $rules.capability.matchingCount) -}}{{- fail "llm.connections native_capability_blocked" -}}{{- end -}}
  {{- if or (ne (get (first $matches) "status") $rules.capability.admittedStatus) (ne (get (first $matches) "api") $api) -}}{{- fail "llm.connections native_capability_blocked" -}}{{- end -}}
  {{- $prefix := printf "PHOENIX_LLM_%s_" (upper $name) -}}
  {{- range $field := list "PLATFORM" "PUBLISHER" "NATIVE_PROVIDER" "API" "BASE_URL" "AUTH_MODE" "API_KEY_ENV" "NATIVE_ENV_REFS_JSON" "HEADERS_JSON" -}}
    {{- if or (hasKey $connection $field) (eq $field "API") -}}
      {{- $value := get $connection $field -}}
      {{- if eq $field "API" -}}{{- $value = $api -}}{{- end -}}
      {{- if or (eq $field "NATIVE_ENV_REFS_JSON") (eq $field "HEADERS_JSON") -}}{{- $value = toJson $value -}}{{- end -}}
      {{- $_ := set $plain (printf "%s%s" $prefix $field) $value -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- range $name := keys $platform -}}
  {{- $used := false -}}
  {{- range $connection := values $llm.connections -}}
    {{- range $_, $destination := $connection.NATIVE_ENV_REFS_JSON | default dict -}}
      {{- if eq $destination $name -}}{{- $used = true -}}{{- end -}}
    {{- end -}}
  {{- end -}}
  {{- if not $used -}}{{- fail "llm.platformEnv unused_source" -}}{{- end -}}
{{- end -}}
{{- dict "env" $plain | toJson -}}
{{- end -}}
