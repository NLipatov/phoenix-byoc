{{- define "phoenix-workflow-engine.agentInputsName" -}}
{{- printf "%s-agent-inputs" (include "phoenix-workflow-engine.fullname" . | trunc 50 | trimSuffix "-") -}}
{{- end -}}

{{- /* Return validated complete maps; reject overlaps before combining sources. */ -}}
{{- define "phoenix-workflow-engine.agentInputs" -}}
{{- $generic := .Values.agentInputDelivery -}}
{{- $plain := dict -}}
{{- $secrets := dict -}}
{{- $owners := dict -}}
{{- if .Values.llm -}}
  {{- $named := include "phoenix-workflow-engine.llmInputs" . | fromJson -}}
  {{- range $name, $value := $named.env -}}
    {{- $_ := set $owners $name "llm.connections" -}}
    {{- $_ := set $plain $name $value -}}
  {{- end -}}
{{- end -}}
{{- range $source, $input := dict "agentInputDelivery" $generic "llm" (.Values.llm | default dict) -}}
  {{- range $name, $value := ($input.env | default dict) -}}
    {{- if regexMatch `\x00` $value -}}{{- fail (printf "%s.env source_required" $source) -}}{{- end -}}
    {{- if hasKey $owners $name -}}
      {{- fail (printf "%s.env destination_collision overlaps %s" $source (index $owners $name)) -}}
    {{- end -}}
    {{- $_ := set $owners $name (printf "%s.env" $source) -}}
    {{- $_ := set $plain $name $value -}}
  {{- end -}}
  {{- range $name, $reference := ($input.secretEnv | default dict) -}}
    {{- if hasKey $owners $name -}}
      {{- fail (printf "%s.secretEnv destination_collision overlaps %s" $source (index $owners $name)) -}}
    {{- end -}}
    {{- $_ := set $owners $name (printf "%s.secretEnv" $source) -}}
    {{- $_ := set $secrets $name $reference -}}
  {{- end -}}
{{- end -}}
{{- if gt (len $plain) 256 -}}{{- fail "agent inputs exceed 256 plain destinations" -}}{{- end -}}
{{- if gt (len $secrets) 128 -}}{{- fail "agent inputs exceed 128 secret destinations" -}}{{- end -}}
{{- $envJSON := toJson $plain -}}
{{- $policyJSON := toJson (dict "version" 1 "allowedEnterpriseIds" $generic.allowedEnterpriseIds) -}}
{{- if gt (len $envJSON) 65536 -}}{{- fail "agent inputs env.json exceeds 65536 bytes" -}}{{- end -}}
{{- if gt (len $policyJSON) 65536 -}}{{- fail "agent inputs delivery-policy.json exceeds 65536 bytes" -}}{{- end -}}
{{- $directory := "/var/run/phoenix/agent-inputs" -}}
{{- range .Values.operator.extraVolumes -}}
  {{- if eq .name "agent-inputs" -}}{{- fail "operator.extraVolumes reserves agent-inputs" -}}{{- end -}}
{{- end -}}
{{- range .Values.operator.extraVolumeMounts -}}
  {{- if eq .name "agent-inputs" -}}{{- fail "operator.extraVolumeMounts reserves agent-inputs" -}}{{- end -}}
  {{- $path := clean .mountPath -}}
  {{- if or (eq $path "/") (eq $path $directory) (hasPrefix (printf "%s/" $path) $directory) (hasPrefix (printf "%s/" $directory) $path) -}}
    {{- fail "operator.extraVolumeMounts overlaps agent inputs directory" -}}
  {{- end -}}
{{- end -}}
{{- range $name, $_ := .Values.csg.scriptEnv -}}
  {{- if has $name (list "PHOENIX_AGENT_INPUTS_DIR" "PHOENIX_AGENT_SECRET_NAMES_JSON" "PHOENIX_LLM_CONFIG_VERSION" "PHOENIX_LLM_CONNECTIONS") -}}
    {{- fail (printf "csg.scriptEnv.%s overrides agent input transport" $name) -}}
  {{- end -}}
{{- end -}}
{{- dict "env" $envJSON "policy" $policyJSON "secrets" $secrets | toJson -}}
{{- end -}}
